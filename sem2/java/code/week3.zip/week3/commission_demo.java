import java.util.Scanner;

class Commission {
    private double sales;

    // Constructor
    public Commission(double sales) {
        this.sales = sales;
    }

    // Method to calculate commission
    public double commission() {
        if (sales < 0) {
            return -1; // Indicates invalid input
        } else {
            // Assuming commission rate is 10%
            return sales * 0.10;
        }
    }
}

public class commission_demo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Read sales from the user
        System.out.print("Enter the sales amount: ");
        double sales = sc.nextDouble();

        // Validate sales
        if (sales < 0) {
            System.out.println("Invalid Input");
        } else {
            // Create Commission object
            Commission ob  = new Commission(sales);

            // Calculate and print commission
            double amount = ob.commission();
            if (amount == -1) {
                System.out.println("Invalid Input");
            } else {
                System.out.println("Commission: Rs " + amount);
            }
        }

        sc.close();
    }
}
