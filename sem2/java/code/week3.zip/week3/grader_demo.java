import java.util.Scanner;

class Grader {
    private int score;

    // Constructor
    public Grader(int score) {
        this.score = score;
    }

    // Method to return the letter grade
    public String letterGrade() {
        if (score < 0 || score > 100) {
            return "Invalid Score";
        } else if (score >= 90) {
            return "O";
        } else if (score >= 80) {
            return "E";
        } else if (score >= 70) {
            return "A";
        } else if (score >= 60) {
            return "B";
        } else if (score >= 50) {
            return "C";
        } else {
            return "F";
        }
    }
}

public class grader_demo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Read score from the user
        System.out.print("Enter the score: ");
        int score = sc.nextInt();

        // Validate score
        if (score < 0 || score > 100) {
            System.out.println("Invalid score. Score must be between 0 and 100.");
        } else {
            // Create Grader object
            Grader ob = new Grader(score);

            // Print the letter grade
            System.out.println("Letter Grade: " + ob.letterGrade());
        }

        sc.close();
    }
}
