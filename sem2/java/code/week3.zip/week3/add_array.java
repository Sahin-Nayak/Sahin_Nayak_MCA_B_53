import java.util.Scanner;

public class add_array {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input the size of the arrays
        System.out.print("Enter the size of the arrays: ");
        int size = sc.nextInt();

        // Input the elements of the first array
        int[] arr1 = new int[size];
        System.out.println("Enter the elements of the first array:");
        for (int i = 0; i < size; i++) {
            arr1[i] = sc.nextInt();
        }

        // Input the elements of the second array
        int[] arr2 = new int[size];
        System.out.println("Enter the elements of the second array:");
        for (int i = 0; i < size; i++) {
            arr2[i] = sc.nextInt();
        }

        // Add the elements index-wise and store into a third array
        int[] resultArray = new int[size];
        for (int i = 0; i < size; i++) {
            resultArray[i] = arr1[i] + arr2[i];
        }

        // Display the result array
        System.out.println("Result array:");
        for (int num : resultArray) {
            System.out.print(num + " ");
        }

        sc.close();
    }
}
