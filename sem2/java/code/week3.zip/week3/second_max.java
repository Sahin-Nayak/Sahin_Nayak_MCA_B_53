
import java.util.*;
class second_max {


	static void sec_max(Integer arr[], int arr_size)
	{
		// Sort the array in descending order
		Arrays.sort(arr, Collections.reverseOrder());
		// Start from second element as first
		// element is the largest
		for (int i = 1; i < arr_size; i++) {
			// If the element is not
			// equal to largest element
			if (arr[i] != arr[0]) {
				System.out.printf("The second largest "
									+ "element is %d\n",
								arr[i]);
				return;
			}
		}

		System.out.printf("There is no second "
						+ "largest element\n");
	}

	// Driver code
	public static void main(String[] args)
	{
Scanner sc=new Scanner(System.in);
 // Input the size of the array
        System.out.print("Enter the size of the array: ");
        int n = sc.nextInt();

        // Input the elements of the array

Integer[] arr = new Integer[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

		
		sec_max(arr, n);
	}
}

