import java.util.*;
public class duplicates_frequency_array{

   //main method
   public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
 // Input the size of the array
        System.out.print("Enter the size of the array: ");
        int n = sc.nextInt();

        // Input the elements of the array

int[] array = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            array[i] = sc.nextInt();
        }

   
      
      
      //sorting an array
      Arrays.sort(array);
      
      //declaring the variables
      int i,j,frequency;
      System.out.println("These elements are repeated along with its frequency-");
      
      //loop for logic implementation
      for(i=0; i<array.length; i++){
         frequency = 1;
         for(j=i+1; j<array.length; j++){
            if(array[j] == array[i]){
               frequency++;
            } else {
               break;
            }
         }
         i=j-1;
         if(frequency > 1){
         
            //printing the output
            System.out.println(array[i] + " --> " + frequency);
         }
      }
   }
   
}