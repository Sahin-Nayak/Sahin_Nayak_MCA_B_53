import java.util.Scanner;

public class Celsius_Fahrenheit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Prompt the user to enter temperature in Celsius
        System.out.print("Enter temperature in Celsius: ");
        double c = sc.nextDouble();

        // Convert Celsius to Fahrenheit
        double f = (c * 9/5) + 32;

        // Display the result
        System.out.println("Temperature in Fahrenheit: " + f);

        sc.close();
    }
}
