import java.util.Scanner;

public class multiplication_table {
    public static void main(String[] args) {
        // Create a Scanner object to read input
        Scanner sc = new Scanner(System.in);
        
        // Prompt the user to enter the number for the multiplication table
        System.out.print("Enter the number for the multiplication table: ");
        int number = sc.nextInt();
        
        // Prompt the user to enter the range
        System.out.print("Enter the range for the multiplication table: ");
        int range = sc.nextInt();
        
        // Close the scanner
        sc.close();
        
        // Generate and print the multiplication table
        System.out.println("Multiplication table for " + number + " up to " + range + ":");
        for (int i = 1; i <= range; i++) {
            System.out.println(number + " x " + i + " = " + (number * i));
        }
    }
}
