import java.util.Scanner;

public class buzz_number {
    public static void main(String[] args) {
        // Create a Scanner object to read input
        Scanner sc = new Scanner(System.in);
        
        // Prompt the user to enter a number
        System.out.print("Enter a number: ");
        int number = sc.nextInt();
        
        // Close the scanner
        sc.close();
        
        
        // Print the result
        if ((number % 7 == 0) || (number % 10 == 7)) {
            System.out.println(number + " is a Buzz number.");
        } else {
            System.out.println(number + " is not a Buzz number.");
        }
    }
}
