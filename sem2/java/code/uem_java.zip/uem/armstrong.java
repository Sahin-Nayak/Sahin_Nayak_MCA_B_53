import java.util.Scanner;

public class armstrong {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Read the number from the user
        System.out.print("Enter a number: ");
        int num = sc.nextInt();
 int ori, rem, result = 0, n = 0;

        ori = num;

        // Count the number of digits
        for (ori = num; ori != 0; ori /= 10) {
            ++n;
        }

        ori = num;

        // Calculate result
        while (ori != 0) {
            rem = ori % 10;
            result += Math.pow(rem, n);
            ori /= 10;
        }

        // Check if the number is Armstrong
        if (result == num) {
            System.out.println(num + " is an Armstrong number.");
        } else {
            System.out.println(num + " is not an Armstrong number.");
        }

        sc.close();
    }

    
    }

