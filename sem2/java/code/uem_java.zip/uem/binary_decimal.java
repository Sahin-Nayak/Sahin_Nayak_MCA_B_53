import java.util.Scanner;

public class binary_decimal {
    public static void main(String[] args) {
        // Create a Scanner object to read input
        Scanner sc = new Scanner(System.in);

        // Prompt the user for conversion type
        System.out.println("Choose conversion:");
        System.out.println("1. Binary to Decimal");
        System.out.println("2. Decimal to Binary");
        System.out.print("Enter your choice (1 or 2): ");
        int choice = sc.nextInt();

        // Perform the conversion based on the choice
        switch (choice) {
            case 1:
                binaryToDecimal();
                break;
            case 2:
                decimalToBinary();
                break;
            default:
                System.out.println("Invalid choice. Please enter 1 or 2.");
        }

        // Close the scanner
        sc.close();
    }

    // Method to convert binary to decimal
    public static void binaryToDecimal() {
        // Prompt the user to enter a binary number
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a binary number: ");
        String binaryString = sc.nextLine();
        sc.close();

        // Convert binary string to decimal
        int decimal = Integer.parseInt(binaryString, 2);

        // Print the decimal equivalent
        System.out.println("Decimal equivalent: " + decimal);
    }

    // Method to convert decimal to binary
    public static void decimalToBinary() {
        // Prompt the user to enter a decimal number
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a decimal number: ");
        int decimal = sc.nextInt();
        sc.close();

        // Convert decimal to binary string
        String binaryString = Integer.toBinaryString(decimal);

        // Print the binary equivalent
        System.out.println("Binary equivalent: " + binaryString);
    }
}
