import java.util.Scanner;

public class miles_kilometers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Prompt the user to enter distance in miles
        System.out.print("Enter distance in miles: ");
        double m = sc.nextDouble();

        // Convert miles to kilometers
        double km = m * 1.60934;

        // Display the result
        System.out.println(m + " miles is equal to " + km + " kilometers.");

        sc.close();
    }
}
