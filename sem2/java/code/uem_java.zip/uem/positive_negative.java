import java.util.Scanner;

public class positive_negative {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Prompt the user to enter a number
        System.out.print("Enter a number: ");
        int n = sc.nextInt();

        // Check if the number is positive or negative
        if (n>0) {
            System.out.println(n + " is positive.");
        } else {
            System.out.println(n + " is negative.");
        }

        sc.close();
    }
}
