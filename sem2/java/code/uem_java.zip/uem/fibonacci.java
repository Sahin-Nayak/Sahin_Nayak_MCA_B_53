import java.util.Scanner;

public class fibonacci {
    public static void main(String[] args) {
        // Create a Scanner object to read input
        Scanner sc = new Scanner(System.in);
        
        // Prompt the user to enter the number of terms for Fibonacci series
        System.out.print("Enter the number of terms for Fibonacci series: ");
        int num = sc.nextInt();
        
        // Close the scanner
        sc.close();
        
        // Generate Fibonacci series
        int prev = 0, curr = 1;
        System.out.println("Fibonacci series:");
        for (int i = 1; i <= num; ++i) {
            System.out.print(prev + " ");
            int next = prev + curr;
            prev = curr;
            curr = next;
        }
    }
}
