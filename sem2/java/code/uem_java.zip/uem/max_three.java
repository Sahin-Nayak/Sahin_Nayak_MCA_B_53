import java.util.Scanner;

public class max_three {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Prompt the user to enter three numbers
        System.out.println("Enter three numbers:");
        System.out.print("1st number: ");
        double num1 = sc.nextDouble();
        System.out.print("2nd number: ");
        double num2 = sc.nextDouble();
        System.out.print("3rd number: ");
        double num3 = sc.nextDouble();

        // Find the maximum of the three numbers
        double max = num1;
        if (num2 > max) {
            max = num2;
        }
        if (num3 > max) {
            max = num3;
        }

        // Display the maximum number
        System.out.println("The maximum of the three numbers is: " + max);

        sc.close();
    }
}
