public class name {
    public static void main(String[] args) {
        // Print my name
        System.out.println("Hrisha Gossain");
    }
}
