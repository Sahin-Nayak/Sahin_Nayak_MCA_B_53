import java.util.Scanner;

public class count_digits {
    public static void main(String[] args) {
        // Create a Scanner object to read input
        Scanner sc = new Scanner(System.in);
        
        // Prompt the user to enter an integer
        System.out.print("Enter an integer: ");
        int number = sc.nextInt();
        
        // Close the scanner
        sc.close();
        
        // Count the number of digits
        int count = 0;
        int temp = number;
        while (temp != 0) {
            temp /= 10;
            count++;
        }
        
        // Print the number of digits
        System.out.println("Number of digits in " + number + " is: " + count);
    }
}
