import java.util.Scanner;

public class factorial {
    public static void main(String[] args) {
        // Create a Scanner object to read input
        Scanner sc = new Scanner(System.in);
        
        // Prompt the user to enter a number
        System.out.print("Enter a number: ");
        int number = sc.nextInt();
        
        // Close the scanner
        sc.close();
        
        // Calculate the factorial of the number
        long factorial = 1;
        
        for (int i = 1; i <= number; i++) {
            factorial *= i;
        }
        
        // Print the factorial
        System.out.println("Factorial of " + number + " is: " + factorial);
    }
}
