import java.util.Scanner;

public class square {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Prompt the user to enter the length and width of the rectangle
        System.out.print("Enter the side of the square: ");
        double s = sc.nextDouble();

        

        // Calculate area and perimeter
        double area = s*s;
        double peri = 4 * s;

        // Display the results
        System.out.println("Area of the square: " + area);
        System.out.println("Perimeter of the square: " + peri);

        sc.close();
    }
}