import java.util.Scanner;

public class grade {
    public static void main(String[] args) {
        // Create a Scanner object to read input
        Scanner sc = new Scanner(System.in);
        
        // Prompt the user to enter percentage
        System.out.print("Enter the percentage: ");
        double percentage = sc.nextDouble();
        
        // Close the scanner
        sc.close();
        
        // Determine the grade based on the percentage
        char grade;
        
        if (percentage >= 90) {
            grade = 'A';
        } else if (percentage >= 80) {
            grade = 'B';
        } else if (percentage >= 70) {
            grade = 'C';
        } else if (percentage >= 60) {
            grade = 'D';
        } else if (percentage >= 40) {
            grade = 'E';
        } else {
            grade = 'F';
        }
        
        // Print the grade
        System.out.println("Grade: " + grade);
    }
}
