import java.util.Scanner;

public class prime_range {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Read input values
        System.out.print("Enter the starting number of the interval: ");
        int start = sc.nextInt();

        System.out.print("Enter the ending number of the interval: ");
        int end = sc.nextInt();

        System.out.println("Prime numbers between " + start + " and " + end + ":");
        
        // Iterate through the interval and check for prime numbers
        for (int i = start; i <= end; i++) {
            if (isPrime(i)) {
                System.out.println(i);
            }
        }

        sc.close();
    }

    // Method to check if a number is prime
    public static boolean isPrime(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}
