import java.util.Scanner;

// Base class Vehicle
class Vehicle {
    protected int Wheels;
    protected double speed;

    public Vehicle(int Wheels, double speed) {
        this.Wheels = Wheels;
        this.speed = speed;
    }

    public double getSpeed() {
        return speed;
    }

    public void displayInfo() {
        System.out.println("Number of Wheels: " + Wheels);
        System.out.println("Speed: " + speed + " mph");
    }
}

// Derived class Car
class Car extends Vehicle {
    private int Passengers;

    public Car(int Wheels, double speed, int Passengers) {
        super(Wheels, speed);
        this.Passengers = Passengers;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Number of Passengers: " + Passengers);
    }
}

// Derived class Truck
class Truck extends Vehicle {
    private double loadLimit;

    public Truck(int Wheels, double speed, double loadLimit) {
        super(Wheels, speed);
        this.loadLimit = loadLimit;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Load Limit: " + loadLimit + " tons");
    }
}

public class vehicle_car_truck {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input for Car
        System.out.println("Enter details for Car:");
        System.out.print("Number of Wheels: ");
        int carWheels = sc.nextInt();
        System.out.print("Speed (mph): ");
        double carSpeed = sc.nextDouble();
        System.out.print("Number of Passengers: ");
        int passengers = sc.nextInt();

        // Input for Truck
        System.out.println("\nEnter details for Truck:");
        System.out.print("Number of Wheels: ");
        int truckWheels = sc.nextInt();
        System.out.print("Speed (mph): ");
        double truckSpeed = sc.nextDouble();
        System.out.print("Load Limit (tons): ");
        double loadLimit = sc.nextDouble();

        // Creating objects
        Car c = new Car(carWheels, carSpeed, passengers);
        Truck t = new Truck(truckWheels, truckSpeed, loadLimit);

        // Displaying information about Car and Truck
        System.out.println("\nInformation about Car:");
        c.displayInfo();
        System.out.println("\nInformation about Truck:");
        t.displayInfo();

        // Comparing speeds
        if (c.getSpeed() > t.getSpeed()) {
            System.out.println("\nCar is faster than Truck.");
        } else if (c.getSpeed() < t.getSpeed()) {
            System.out.println("\nTruck is faster than Car.");
        } else {
            System.out.println("\nCar and Truck have the same speed.");
        }

        sc.close();
    }
}
