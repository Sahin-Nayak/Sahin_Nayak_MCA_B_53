class Superclass {
    static void display() {
        System.out.println("Static method in Superclass");
    }
}

class Subclass extends Superclass {
    static void display() {
        System.out.println("Static method in Subclass");
    }
}

public class method_hiding {
    public static void main(String[] args) {
        // Call the static method in Superclass
        Superclass.display(); // Output: Static method in Superclass
        
        // Call the static method in Subclass
        Subclass.display(); // Output: Static method in Subclass
        
        // Demonstrating method hiding
        // Access the static method in Subclass using Superclass reference
        Superclass ref = new Subclass();
        ref.display(); // Output: Static method in Superclass
    }
}
