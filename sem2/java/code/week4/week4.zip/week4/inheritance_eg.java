class stu {

  // field and method of the parent class
  String name;
  public void message() {
    System.out.println("I am student of MCA");
  }
}

// inherit from stu
class Name extends stu {

  // new method in subclass
  public void display() {
    System.out.println("My name is " + name);
  }
}

class inheritance_eg {
  public static void main(String[] args) {

    // create an object of the subclass
    Name ob = new Name();

    // access field of superclass
    ob.name = "Hrisha";
    ob.display();

    // call method of superclass
    // using object of subclass
    ob.message();

  }
}