import java.util.Scanner;

// Base class Num
class Num {
    protected int number;

    public Num(int number) {
        this.number = number;
    }

    public void showNum() {
        System.out.println("Number: " + number);
    }
}

// Derived class HexNum
class HexNum extends Num {
    public HexNum(int number) {
        super(number);
    }

    @Override
    public void showNum() {
        System.out.println("Hexadecimal Value: " + Integer.toHexString(number));
    }
}

public class num_hexnum{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input for number
        System.out.print("Enter an integer number: ");
        int number = sc.nextInt();

        // Creating objects
        Num num = new Num(number);
        HexNum hexNum = new HexNum(number);

        // Displaying numbers
        System.out.println("\nDisplaying number using Num:");
        num.showNum();
        System.out.println("\nDisplaying number using HexNum:");
        hexNum.showNum();

        sc.close();
    }
}
