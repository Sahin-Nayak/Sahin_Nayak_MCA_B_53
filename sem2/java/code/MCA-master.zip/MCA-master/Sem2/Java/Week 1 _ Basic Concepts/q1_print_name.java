import java.util.*;

class q1_print_name {
    static Scanner sc = new Scanner(System.in);

    public static void main(String args[]) {
        System.out.print("Enter Name: ");
        String s = sc.nextLine();
        System.out.println("Your Name is: " + s);
    }
}
