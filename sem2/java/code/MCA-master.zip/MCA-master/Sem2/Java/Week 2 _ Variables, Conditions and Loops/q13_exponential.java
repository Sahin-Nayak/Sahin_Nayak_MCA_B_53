import java.util.*;

class q13_exponential {
    static Scanner sc = new Scanner(System.in);

    public static void main(String args[]) {
        System.out.print("Enter a Number: ");
        double n = sc.nextDouble();
        System.out.println(Math.exp(n));
    }
}
