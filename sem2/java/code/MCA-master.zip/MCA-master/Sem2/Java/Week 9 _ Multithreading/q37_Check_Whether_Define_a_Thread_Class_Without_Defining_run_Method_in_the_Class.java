public class q37_Check_Whether_Define_a_Thread_Class_Without_Defining_run_Method_in_the_Class {
    public static void main(String[] args) {
        Thread thread = new Thread();
        thread.start();
    }
}
