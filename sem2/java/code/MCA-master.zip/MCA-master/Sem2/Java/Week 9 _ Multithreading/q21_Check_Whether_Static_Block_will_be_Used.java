public class q21_Check_Whether_Static_Block_will_be_Used {
    static {
        System.out.println("Static block is executed.");
    }
    public static void main(String[] args) {
        System.out.println("Main method is executed.");
    }
}
