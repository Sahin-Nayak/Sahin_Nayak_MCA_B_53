import java.util.Scanner;

class Tender {
    private double cost;
    private String companyName;

    public Tender(String companyName, double cost) {
        this.companyName = companyName;
        this.cost = cost;
    }

    public double getCost() {
        return cost;
    }

    public String getCompanyName() {
        return companyName;
    }
}

public class tender_cost_companyname {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Create an array of Tender objects to store data for five tenders
        Tender[] tenders = new Tender[5];

        // Accept data for each tender
        for (int i = 0; i < tenders.length; i++) {
            System.out.println("Enter details for Tender " + (i + 1) + ":");
            System.out.print("Company Name: ");
            String companyName = sc.nextLine();
            System.out.print("Cost: ");
            double cost = sc.nextDouble();

            tenders[i] = new Tender(companyName, cost);
            sc.nextLine(); // Consume newline character
        }

        // Find the tender with the minimum cost
        Tender minCostTender = tenders[0];
        for (int i = 1; i < tenders.length; i++) {
            if (tenders[i].getCost() < minCostTender.getCost()) {
                minCostTender = tenders[i];
            }
        }

        // Display the company name for the tender with the minimum cost
        System.out.println("\nCompany with Minimum Cost:");
        System.out.println("Company Name: " + minCostTender.getCompanyName());
        System.out.println("Cost: " + minCostTender.getCost());

        sc.close();
    }
}
