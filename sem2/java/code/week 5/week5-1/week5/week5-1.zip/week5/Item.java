package week5;

import java.util.Scanner;

class Item {
    int code;
    double price;

    // Parameterized constructor
    public Item(int code, double price) {
        this.code = code;
        this.price = price;
    }
}



