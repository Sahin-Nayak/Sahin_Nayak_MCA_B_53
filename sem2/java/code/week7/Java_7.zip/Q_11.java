public class Q_11 {

    public static void main(String[] args) {
        try {
            // Dummy values for the equation variables
            int X = 10;
            int Y = 20;
            int P = 30;
            int Q = 0; // This will cause a division by zero exception
            int Z = 40;
            int I = 50;

            // Calculate the equation X + Y * (P/Q) * Z - I
            int result = calculateEquation(X, Y, P, Q, Z, I);
            System.out.println("The result of the equation is: " + result);
        } catch (ArithmeticExceptionHandler e) {
            System.out.println("Arithmetic Exception Occurred: " + e.getMessage());
        }
    }

    public static int calculateEquation(int X, int Y, int P, int Q, int Z, int I) throws ArithmeticExceptionHandler {
        if (Q == 0) {
            throw new ArithmeticExceptionHandler("Cannot divide by zero");
        }
        if (P % Q != 0) {
            throw new ArithmeticExceptionHandler("Invalid operation: Non-integer division");
        }
        return X + Y * (P / Q) * Z - I;
    }

    // Custom exception class
    static class ArithmeticExceptionHandler extends Exception {
        public ArithmeticExceptionHandler(String message) {
            super(message);
        }
    }
}